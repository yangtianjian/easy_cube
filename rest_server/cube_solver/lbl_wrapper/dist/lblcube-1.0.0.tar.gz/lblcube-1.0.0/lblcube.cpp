#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <iostream>
#include <string>

using namespace std;
//-----------------------------------------------
// We make up face on the top and front face on the front
struct Cube_t {
    char up[9];
    char front[9];
    char back[9];
    char ri[9];
    char lft[9];
    char bottom[9];
};

//----------------------------------
static void display(char face[9]) {
    for (int i = 0; i < 9; i++) {
        cout << face[i] << " ";
    }
    cout << endl << endl;
}

static void swap(char &a, char &b) {
    char t = a;
    a = b;
    b = t;
}

static void operate_clock(Cube_t& cb, char choice) {
    if (choice == 'w') {
        swap(cb.up[7], cb.up[3]);
        swap(cb.up[6], cb.up[4]);
        swap(cb.up[0], cb.up[2]);
        swap(cb.up[7], cb.up[5]);
        swap(cb.up[0], cb.up[4]);
        swap(cb.up[1], cb.up[3]);
        //-------------------------
        swap(cb.ri[0], cb.back[0]);
        swap(cb.ri[7], cb.back[7]);
        swap(cb.ri[6], cb.back[6]);
        swap(cb.back[6], cb.lft[6]);
        swap(cb.back[7], cb.lft[7]);
        swap(cb.back[0], cb.lft[0]);
        swap(cb.lft[6], cb.front[6]);
        swap(cb.lft[7], cb.front[7]);
        swap(cb.lft[0], cb.front[0]);
    }
        //-------------------------
    else if (choice == 'r') {
        swap(cb.front[0], cb.front[4]);
        swap(cb.front[7], cb.front[5]);
        swap(cb.front[1], cb.front[3]);
        swap(cb.front[0], cb.front[6]);
        swap(cb.front[1], cb.front[5]);
        swap(cb.front[2], cb.front[4]);
        //-------------------------
        swap(cb.ri[6], cb.up[3]);
        swap(cb.ri[5], cb.up[2]);
        swap(cb.ri[4], cb.up[1]);
        swap(cb.up[1], cb.lft[0]);
        swap(cb.up[2], cb.lft[1]);
        swap(cb.up[3], cb.lft[2]);
        swap(cb.lft[0], cb.bottom[3]);
        swap(cb.lft[1], cb.bottom[2]);
        swap(cb.lft[2], cb.bottom[1]);
        //--------------------------
    }
        //-----------------------------------
    else if (choice == 'y') {
        swap(cb.bottom[1], cb.bottom[5]);
        swap(cb.bottom[2], cb.bottom[4]);
        swap(cb.bottom[0], cb.bottom[6]);
        swap(cb.bottom[1], cb.bottom[3]);
        swap(cb.bottom[0], cb.bottom[4]);
        swap(cb.bottom[7], cb.bottom[5]);
        //--------------------------
        swap(cb.ri[4], cb.front[4]);
        swap(cb.ri[3], cb.front[3]);
        swap(cb.ri[2], cb.front[2]);
        swap(cb.front[2], cb.lft[2]);
        swap(cb.front[3], cb.lft[3]);
        swap(cb.front[4], cb.lft[4]);
        swap(cb.lft[4], cb.back[4]);
        swap(cb.lft[3], cb.back[3]);
        swap(cb.lft[2], cb.back[2]);
        //--------------------------
    }
        //-------------------------------------
    else if (choice == 'o') {
        swap(cb.back[4], cb.back[0]);
        swap(cb.back[3], cb.back[1]);
        swap(cb.back[5], cb.back[7]);
        swap(cb.back[4], cb.back[2]);
        swap(cb.back[5], cb.back[1]);
        swap(cb.back[6], cb.back[0]);
        //--------------------------
        swap(cb.ri[2], cb.bottom[5]);
        swap(cb.ri[1], cb.bottom[6]);
        swap(cb.ri[0], cb.bottom[7]);
        swap(cb.bottom[5], cb.lft[6]);
        swap(cb.bottom[6], cb.lft[5]);
        swap(cb.bottom[7], cb.lft[4]);
        swap(cb.lft[6], cb.up[7]);
        swap(cb.lft[5], cb.up[6]);
        swap(cb.lft[4], cb.up[5]);
        //--------------------------
    }
        //-------------------------------------
    else if (choice == 'g') {
        swap(cb.lft[6], cb.lft[2]);
        swap(cb.lft[5], cb.lft[3]);
        swap(cb.lft[7], cb.lft[1]);
        swap(cb.lft[4], cb.lft[6]);
        swap(cb.lft[7], cb.lft[3]);
        swap(cb.lft[0], cb.lft[2]);
        //--------------------------
        swap(cb.up[5], cb.back[2]);
        swap(cb.up[4], cb.back[1]);
        swap(cb.up[3], cb.back[0]);
        swap(cb.bottom[3], cb.back[2]);
        swap(cb.bottom[4], cb.back[1]);
        swap(cb.bottom[5], cb.back[0]);
        swap(cb.bottom[3], cb.front[6]);
        swap(cb.bottom[4], cb.front[5]);
        swap(cb.bottom[5], cb.front[4]);
        //--------------------------
    }
        //-------------------------------------------
    else if (choice == 'b') {
        swap(cb.ri[1], cb.ri[7]);
        swap(cb.ri[2], cb.ri[6]);
        swap(cb.ri[5], cb.ri[3]);
        swap(cb.ri[2], cb.ri[0]);
        swap(cb.ri[7], cb.ri[3]);
        swap(cb.ri[6], cb.ri[4]);
        //--------------------------
        swap(cb.bottom[1], cb.back[4]);
        swap(cb.bottom[0], cb.back[5]);
        swap(cb.bottom[7], cb.back[6]);
        swap(cb.up[7], cb.back[4]);
        swap(cb.up[0], cb.back[5]);
        swap(cb.up[1], cb.back[6]);
        swap(cb.up[7], cb.front[0]);
        swap(cb.up[0], cb.front[1]);
        swap(cb.up[1], cb.front[2]);
        //--------------------------
    }
}

static void rotate_clock(Cube_t& c, char choice) {
    operate_clock(c, choice);
}

static void rotate_anticlock(Cube_t& c, char choice) {
    operate_clock(c, choice);
    operate_clock(c, choice);
    operate_clock(c, choice);
}

static void white_bottom(Cube_t& cb, char q) {
    if ((cb.bottom[0] == 'w' && cb.ri[3] == q) || (cb.bottom[2] == 'w' && cb.front[3] == q) ||
        (cb.bottom[4] == 'w' && cb.lft[3] == q) || (cb.bottom[6] == 'w' && cb.back[3] == q)) {
        if (q == 'b') {
            while (cb.ri[3] != q || cb.bottom[0] != 'w') { rotate_clock(cb, 'y'); }
        }
        if (q == 'r') {
            while (cb.front[3] != q || cb.bottom[2] != 'w') { rotate_clock(cb, 'y'); }
            if (q != 'b') {
                while (cb.up[0] != 'w' && cb.ri[7] != 'b') { rotate_clock(cb, 'w'); }
            }
        }
        if (q == 'g') {
            while (cb.lft[3] != q || cb.bottom[4] != 'w') { rotate_clock(cb, 'y'); }
            if (q != 'b') {
                while (cb.up[0] != 'w' && cb.ri[7] != 'b') { rotate_clock(cb, 'w'); }
            }
        }
        if (q == 'o') {
            while (cb.back[3] != q || cb.bottom[6] != 'w') { rotate_clock(cb, 'y'); }
            if (q != 'b') {
                while (cb.up[0] != 'w' && cb.ri[7] != 'b') { rotate_clock(cb, 'w'); }
            }
        }
        rotate_clock(cb, q);
        rotate_clock(cb, q);
    }
}

static void right_alg(Cube_t& cb, char a, char c) {
    rotate_anticlock(cb, a);
    rotate_clock(cb, 'y');
    rotate_clock(cb, a);
    white_bottom(cb, c);
}

static void white_right(Cube_t& cb, char q) {
    if (cb.ri[1] == 'w' || cb.front[1] == 'w' || cb.lft[1] == 'w' || cb.back[1] == 'w') {
        if (cb.ri[5] == q && cb.front[1] == 'w') { right_alg(cb, 'b', q); }
        if (cb.front[5] == q && cb.lft[1] == 'w') { right_alg(cb, 'r', q); }
        if (cb.lft[5] == q && cb.back[1] == 'w') { right_alg(cb, 'g', q); }
        if (cb.back[5] == q && cb.ri[1] == 'w') { right_alg(cb, 'o', q); }
    }
}

static void left_alg(Cube_t& cb, char a, char c) {
    rotate_clock(cb, a);
    rotate_clock(cb, 'y');
    rotate_anticlock(cb, a);
    white_bottom(cb, c);
}

static void white_left(Cube_t& cb, char q) {
    if (cb.ri[5] == 'w' || cb.front[5] == 'w' || cb.lft[5] == 'w' || cb.back[5] == 'w') {
        if (cb.ri[5] == 'w' && cb.front[1] == q) { left_alg(cb, 'r', q); }
        if (cb.front[5] == 'w' && cb.lft[1] == q) { left_alg(cb, 'g', q); }
        if (cb.lft[5] == 'w' && cb.back[1] == q) { left_alg(cb, 'o', q); }
        if (cb.back[5] == 'w' && cb.ri[1] == q) { left_alg(cb, 'b', q); }
    }
}

static void top_alg(Cube_t& cb, char a, char b, char c) {
    rotate_anticlock(cb, a);
    rotate_clock(cb, 'w');
    rotate_clock(cb, b);
    rotate_anticlock(cb, 'w');
    white_bottom(cb, c);
}

static void white_top(Cube_t& cb, char q) {
    if (cb.ri[7] == 'w' && cb.up[0] == q) { top_alg(cb, 'b', 'r', q); }
    if (cb.front[7] == 'w' && cb.up[2] == q) { top_alg(cb, 'r', 'g', q); }
    if (cb.lft[7] == 'w' && cb.up[4] == q) { top_alg(cb, 'g', 'o', q); }
    if (cb.back[7] == 'w' && cb.up[6] == q) { top_alg(cb, 'o', 'b', q); }
}

static void inv_alg(Cube_t& cb, char a, char b, char c) {
    rotate_clock(cb, a);
    rotate_clock(cb, b);
    rotate_anticlock(cb, 'y');
    rotate_anticlock(cb, b);
    rotate_anticlock(cb, a);
    white_bottom(cb, c);
}

static void white_bottom_inverted(Cube_t& cb, char q) {
    if (cb.ri[3] == 'w' || cb.front[3] == 'w' || cb.lft[3] == 'w' || cb.back[3] == 'w') {
        if (cb.ri[3] == 'w' && cb.bottom[0] == q) { inv_alg(cb, 'b', 'r', q); }
        if (cb.front[3] == 'w' && cb.bottom[2] == q) { inv_alg(cb, 'r', 'g', q); }
        if (cb.lft[3] == 'w' && cb.bottom[4] == q) { inv_alg(cb, 'g', 'o', q); }
        if (cb.back[3] == 'w' && cb.bottom[6] == q) { inv_alg(cb, 'o', 'b', q); }
    }
}

static void solve_white_cross(Cube_t& cb) {
    char prefer[4] = {'b', 'r', 'g', 'o'};
    for (int i = 0; i < 4; i++) {
        if (cb.up[0] == 'w' && cb.ri[7] == prefer[i]) { rotate_clock(cb, 'b'); }
        if (cb.up[2] == 'w' && cb.front[7] == prefer[i]) { rotate_clock(cb, 'r'); }
        if (cb.up[4] == 'w' && cb.lft[7] == prefer[i]) { rotate_clock(cb, 'g'); }
        if (cb.up[6] == 'w' && cb.back[7] == prefer[i]) { rotate_clock(cb, 'o'); }
        white_bottom(cb, prefer[i]);
        white_bottom_inverted(cb, prefer[i]);
        white_left(cb, prefer[i]);
        white_right(cb, prefer[i]);
        white_top(cb, prefer[i]);
        if (i != 0) { while (cb.ri[7] != 'b') { rotate_clock(cb, 'w'); }}
        if (cb.up[0] == 'w' && cb.up[2] == 'w' && cb.up[4] == 'w' && cb.up[6] == 'w' && cb.ri[7] == 'b' &&
            cb.front[7] == 'r' && cb.lft[7] == 'g' && cb.back[7] == 'o') { break; }
    }
}

void white_corners_alg_left(Cube_t& cb) {
    rotate_anticlock(cb, 'b');
    rotate_anticlock(cb, 'y');
    rotate_clock(cb, 'b');
}

void white_corners_alg_right(Cube_t& cb) {
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'y');
    rotate_anticlock(cb, 'r');
}

void solve_white_corners(Cube_t& cb) {
    while (cb.front[0] != 'r' || cb.front[6] != 'r' || cb.ri[0] != 'b' || cb.ri[6] != 'b' || cb.back[0] != 'o' || cb.back[6] != 'o' ||
           cb.lft[0] != 'g' || cb.lft[6] != 'g') {
        while (cb.front[7] != 'r') {
            rotate_clock(cb, 'w');
        }
        if (cb.ri[4] == 'w' || cb.front[4] == 'w' || cb.lft[4] == 'w' || cb.back[4] == 'w') {
            while (cb.ri[4] != 'w') {
                rotate_clock(cb, 'y');
            }
            while (cb.front[2] != cb.front[7]) {
                rotate_clock(cb, 'w');
            }
            white_corners_alg_left(cb);
            while (cb.front[7] != 'r') {
                rotate_clock(cb, 'w');
            }
        } else if (cb.ri[2] == 'w' || cb.front[2] == 'w' || cb.lft[2] == 'w' || cb.back[2] == 'w') {
            while (cb.front[2] != 'w') {
                rotate_clock(cb, 'y');
            }
            while (cb.front[7] != cb.bottom[1]) {
                rotate_clock(cb, 'w');
            }
            white_corners_alg_right(cb);
            while (cb.front[7] != 'r') {
                rotate_clock(cb, 'w');
            }
        } else if (cb.bottom[1] == 'w' || cb.bottom[3] == 'w' || cb.bottom[5] == 'w' || cb.bottom[7] == 'w') {
            while (cb.bottom[1] != 'w') {
                rotate_clock(cb, 'y');
            }
            while (cb.front[2] != cb.ri[7]) {
                rotate_clock(cb, 'w');
            }
            rotate_anticlock(cb, 'b');
            rotate_clock(cb, 'y');
            rotate_clock(cb, 'y');
            rotate_clock(cb, 'b');
            while (cb.ri[4] != 'w') {
                rotate_clock(cb, 'y');
            }
            while (cb.front[2] != cb.front[7]) {
                rotate_clock(cb, 'w');
            }
            white_corners_alg_left(cb);
            while (cb.front[7] != 'r') {
                rotate_clock(cb, 'w');
            }
        } else {
            while (cb.front[7] == cb.front[0]) {
                rotate_clock(cb, 'w');
            }
            white_corners_alg_left(cb);
            while (cb.front[7] != 'r') {
                rotate_clock(cb, 'w');
            }
        }
    }
}

void middle_place_left_alg(Cube_t& cb, char left, char center) {
    rotate_anticlock(cb, 'y');
    rotate_clock(cb, left);
    rotate_clock(cb, left);
    rotate_clock(cb, left);
    rotate_clock(cb, 'y');
    rotate_clock(cb, left);
    rotate_clock(cb, 'y');
    rotate_clock(cb, center);
    rotate_anticlock(cb, 'y');
    rotate_anticlock(cb, center);
}

void middle_place_right_alg(Cube_t& cb, char center, char right) {
    rotate_clock(cb, 'y');
    rotate_clock(cb, right);
    rotate_anticlock(cb, 'y');
    rotate_anticlock(cb, right);
    rotate_anticlock(cb, 'y');
    rotate_anticlock(cb, center);
    rotate_clock(cb, 'y');
    rotate_clock(cb, center);
}

void solve_middle_layer(Cube_t& cb) {
    while (cb.front[5] != 'r' || cb.front[1] != 'r' || cb.ri[1] != 'b' || cb.ri[5] != 'b' || cb.back[1] != 'o' || cb.back[5] != 'o' ||
           cb.lft[1] != 'g' || cb.lft[5] != 'g') {

        if ((cb.back[1] != 'o' && cb.lft[5] != 'g') && (cb.back[1] != 'y' || cb.lft[5] != 'y')) {
            while (cb.lft[3] != 'y' && cb.bottom[4] != 'y') {
                rotate_clock(cb, 'y');
            }
            middle_place_right_alg(cb, 'g', 'o');
        } else if ((cb.back[5] != 'o' && cb.ri[1] != 'b') && (cb.back[5] != 'y' || cb.ri[1] != 'y')) {
            while (cb.back[3] != 'y' && cb.bottom[6] != 'y') {
                rotate_clock(cb, 'y');
            }
            middle_place_right_alg(cb, 'o', 'b');
        } else if ((cb.ri[5] != 'b' && cb.front[1] != 'r') && (cb.ri[5] != 'y' || cb.front[1] != 'y')) {
            while (cb.ri[3] != 'y' && cb.bottom[0] != 'y') {
                rotate_clock(cb, 'y');
            }
            middle_place_right_alg(cb, 'b', 'r');
        } else if ((cb.front[5] != 'r' && cb.lft[1] != 'g') && (cb.front[5] != 'y' || cb.lft[1] != 'y')) {
            while (cb.front[3] != 'y' && cb.bottom[2] != 'y') {
                rotate_clock(cb, 'y');
            }
            middle_place_right_alg(cb, 'r', 'g');
        }

        while (cb.front[3] == 'y' || cb.bottom[2] == 'y') {
            rotate_clock(cb, 'y');
        }

        if (cb.front[3] == 'r' && cb.bottom[2] != 'y') {
            if (cb.bottom[2] == 'g') {
                middle_place_right_alg(cb, 'r', 'g');
            } else if (cb.bottom[2] == 'b') {
                middle_place_left_alg(cb, 'b', 'r');
            }
        } else if (cb.front[3] == 'b' && cb.bottom[2] != 'y') {
            rotate_clock(cb, 'y');
            if (cb.bottom[0] == 'r') {
                middle_place_right_alg(cb, 'b', 'r');
            } else if (cb.bottom[0] == 'o') {
                middle_place_left_alg(cb, 'o', 'b');
            }
        } else if (cb.front[3] == 'o' && cb.bottom[2] != 'y') {
            rotate_clock(cb, 'y');
            rotate_clock(cb, 'y');
            if (cb.bottom[6] == 'b') {
                middle_place_right_alg(cb, 'o', 'b');
            } else if (cb.bottom[6] == 'g') {
                middle_place_left_alg(cb, 'g', 'o');
            }
        } else if (cb.front[3] == 'g' && cb.bottom[2] != 'y') {
            rotate_anticlock(cb, 'y');
            if (cb.bottom[4] == 'o') {
                middle_place_right_alg(cb, 'g', 'o');
            } else if (cb.bottom[4] == 'r') {
                middle_place_left_alg(cb, 'r', 'g');
            }
        }
    }
}

void yellow_cross_algorithm(Cube_t& cb) {
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'y');
    rotate_clock(cb, 'g');
    rotate_anticlock(cb, 'y');
    rotate_anticlock(cb, 'g');
    rotate_anticlock(cb, 'r');
}

void solve_yellow_cross(Cube_t& cb) {
    while (cb.bottom[0] != 'y' || cb.bottom[2] != 'y' || cb.bottom[4] != 'y' || cb.bottom[6] != 'y') {
        if ((cb.bottom[0] == 'y' && cb.bottom[6] == 'y') || (cb.bottom[4] == 'y' && cb.bottom[6] == 'y')
            || (cb.bottom[2] == 'y' && cb.bottom[4] == 'y') || (cb.bottom[0] == 'y' && cb.bottom[2] == 'y')) {
            while (cb.bottom[0] != 'y' && cb.bottom[6] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_cross_algorithm(cb);
        }
        if ((cb.bottom[2] == 'y' && cb.bottom[6] == 'y') || (cb.bottom[0] == 'y' && cb.bottom[4] == 'y')) {
            while (cb.bottom[0] != 'y' && cb.bottom[4] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_cross_algorithm(cb);
            yellow_cross_algorithm(cb);
        } else if (cb.bottom[8] == 'y') {
            yellow_cross_algorithm(cb);
            rotate_clock(cb, 'y');
            yellow_cross_algorithm(cb);
            yellow_cross_algorithm(cb);
        }
    }
}

void yellow_corners_algorithm(Cube_t& cb) {
    rotate_clock(cb, 'g');
    rotate_clock(cb, 'y');
    rotate_anticlock(cb, 'g');
    rotate_clock(cb, 'y');
    rotate_clock(cb, 'g');
    rotate_clock(cb, 'y');
    rotate_clock(cb, 'y');
    rotate_anticlock(cb, 'g');
}

void solve_yellow_corners(Cube_t& cb) {
    while (cb.bottom[1] != 'y' || cb.bottom[3] != 'y' || cb.bottom[5] != 'y' || cb.bottom[7] != 'y') {
        if ((cb.bottom[1] == 'y' && cb.bottom[3] != 'y' && cb.bottom[5] != 'y' && cb.bottom[7] != 'y')
            || (cb.bottom[3] == 'y' && cb.bottom[1] != 'y' && cb.bottom[5] != 'y' && cb.bottom[7] != 'y')
            || (cb.bottom[5] == 'y' && cb.bottom[1] != 'y' && cb.bottom[3] != 'y' && cb.bottom[7] != 'y')
            || (cb.bottom[7] == 'y' && cb.bottom[1] != 'y' && cb.bottom[3] != 'y' && cb.bottom[5] != 'y')) {
            while (cb.bottom[1] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_corners_algorithm(cb);
        } else if ((cb.lft[2] == 'y' && cb.lft[4] == 'y' && cb.bottom[1] == 'y' && cb.bottom[7] == 'y')
                   || (cb.back[2] == 'y' && cb.back[4] == 'y' && cb.bottom[1] == 'y' && cb.bottom[3] == 'y')
                   || (cb.ri[2] == 'y' && cb.ri[4] == 'y' && cb.bottom[3] == 'y' && cb.bottom[5] == 'y')
                   || (cb.front[2] == 'y' && cb.front[4] == 'y' && cb.bottom[5] == 'y' && cb.bottom[7] == 'y')) {
            while (cb.front[2] != 'y' && cb.front[4] != 'y' && cb.bottom[5] != 'y' && cb.bottom[7] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_corners_algorithm(cb);
        } else if ((cb.front[4] == 'y' && cb.back[2] == 'y' && cb.bottom[1] == 'y' && cb.bottom[7] == 'y')
                   || (cb.ri[2] == 'y' && cb.lft[4] == 'y' && cb.bottom[1] == 'y' && cb.bottom[3] == 'y')
                   || (cb.front[2] == 'y' && cb.back[4] == 'y' && cb.bottom[3] == 'y' && cb.bottom[5] == 'y')
                   || (cb.ri[4] == 'y' && cb.lft[2] == 'y' && cb.bottom[5] == 'y' && cb.bottom[7] == 'y')) {
            while (cb.front[2] != 'y' && cb.back[4] != 'y' && cb.bottom[3] != 'y' && cb.bottom[5] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_corners_algorithm(cb);
        } else if ((cb.lft[2] == 'y' && cb.lft[4] == 'y' && cb.ri[2] == 'y' && cb.ri[4] == 'y')
                   || (cb.front[2] == 'y' && cb.front[4] == 'y' && cb.back[2] == 'y' && cb.back[4] == 'y')) {
            while (cb.lft[2] != 'y' && cb.lft[4] != 'y' && cb.ri[2] != 'y' && cb.ri[4] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_corners_algorithm(cb);
        } else if ((cb.lft[2] == 'y' && cb.back[2] == 'y' && cb.back[4] == 'y' && cb.ri[4] == 'y')
                   || (cb.front[4] == 'y' && cb.back[2] == 'y' && cb.ri[2] == 'y' && cb.ri[4] == 'y')
                   || (cb.front[2] == 'y' && cb.front[4] == 'y' && cb.lft[4] == 'y' && cb.ri[2] == 'y')
                   || (cb.lft[2] == 'y' && cb.lft[4] == 'y' && cb.back[4] == 'y' && cb.front[2] == 'y')) {
            while (cb.lft[2] != 'y' && cb.back[2] != 'y' && cb.back[4] != 'y' && cb.ri[4] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_corners_algorithm(cb);
        } else if ((cb.bottom[1] == 'y' && cb.bottom[5] == 'y' && cb.bottom[3] != 'y' && cb.bottom[7] != 'y')
                   || (cb.bottom[3] == 'y' && cb.bottom[7] == 'y' && cb.bottom[1] != 'y' && cb.bottom[5] != 'y')) {
            while (cb.front[2] != 'y' && cb.lft[4] != 'y') {
                rotate_clock(cb, 'y');
            }
            yellow_corners_algorithm(cb);
        }
    }
}

void yellow_corner_orientation_algorithm(Cube_t& cb) {
    rotate_anticlock(cb, 'g');
    rotate_clock(cb, 'r');
    rotate_anticlock(cb, 'g');
    rotate_clock(cb, 'o');
    rotate_clock(cb, 'o');
    rotate_clock(cb, 'g');
    rotate_anticlock(cb, 'r');
    rotate_anticlock(cb, 'g');
    rotate_clock(cb, 'o');
    rotate_clock(cb, 'o');
    rotate_clock(cb, 'g');
    rotate_clock(cb, 'g');
    rotate_anticlock(cb, 'y');
}

void yellow_corner_orientation(Cube_t& cb) {
    while (cb.front[2] != 'r' || cb.front[4] != 'r' || cb.lft[2] != 'g' || cb.lft[4] != 'g'
           || cb.back[2] != 'o' || cb.back[4] != 'o' || cb.ri[2] != 'b' || cb.ri[4] != 'b') {
        if ((cb.front[2] == cb.front[4]) || (cb.lft[2] == cb.lft[4]) || (cb.back[2] == cb.back[4]) || (cb.ri[2] == cb.ri[4])) {
            while (cb.back[2] != cb.back[4]) {
                rotate_clock(cb, 'y');
            }
            yellow_corner_orientation_algorithm(cb);
            while (cb.ri[2] != 'b') {
                rotate_clock(cb, 'y');
            }
        } else {
            while (cb.back[4] != 'o' && cb.front[4] != 'r') {
                rotate_clock(cb, 'y');
            }
            yellow_corner_orientation_algorithm(cb);
            while (cb.back[2] != cb.back[4]) {
                rotate_clock(cb, 'y');
            }
            yellow_corner_orientation_algorithm(cb);
            while (cb.ri[2] != 'b') {
                rotate_clock(cb, 'y');
            }
        }
    }
}

void yellow_edges_colour_arrangement_right(Cube_t& cb) {
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'r');
    rotate_anticlock(cb, 'y');
    rotate_anticlock(cb, 'g');
    rotate_clock(cb, 'b');
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'r');
    rotate_anticlock(cb, 'b');
    rotate_clock(cb, 'g');
    rotate_anticlock(cb, 'y');
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'r');
}

void yellow_edges_colour_arrangement_left(Cube_t& cb) {
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'y');
    rotate_clock(cb, 'b');
    rotate_anticlock(cb, 'g');
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'r');
    rotate_anticlock(cb, 'b');
    rotate_clock(cb, 'g');
    rotate_clock(cb, 'y');
    rotate_clock(cb, 'r');
    rotate_clock(cb, 'r');
}

void yellow_edges_colour_arrangement(Cube_t& cb) {
    while (cb.front[2] != 'r') {
        rotate_clock(cb, 'r');
    }
    if (cb.front[3] == 'o' && cb.back[3] == 'r' && cb.ri[3] == 'g' && cb.lft[3] == 'b') {
        yellow_edges_colour_arrangement_left(cb);
    } else if (cb.front[3] == 'b' && cb.ri[3] == 'r') {
        yellow_edges_colour_arrangement_left(cb);
    } else if (cb.front[3] == 'g' && cb.lft[3] == 'r') {
        yellow_edges_colour_arrangement_left(cb);
    }
    while (cb.back[2] != cb.back[3]) {
        rotate_clock(cb, 'y');
    }
    if (cb.front[3] == cb.lft[2]) {
        yellow_edges_colour_arrangement_right(cb);
    } else if (cb.front[3] == cb.ri[2]) {
        yellow_edges_colour_arrangement_left(cb);
    }
    while (cb.front[3] != 'r') {
        rotate_clock(cb, 'y');
    }
}

static PyObject * lblcube_system(PyObject *self, PyObject *args)
{
    const char *command;
    int sts;
    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;
    sts = system(command);
    return PyLong_FromLong(sts);
}

static PyMethodDef lbl_cube_methods[] = {
        {"system", lblcube_system, METH_VARARGS,"Execute a shell command."},
        {NULL, NULL, 0, NULL}
};

static PyModuleDef lblcubemodule = {
    PyModuleDef_HEAD_INIT,
    "lblcube",
    NULL,
    -1,
    lbl_cube_methods
};

PyMODINIT_FUNC PyInit_lblcube(void) {
    return PyModule_Create(&lblcubemodule);
}

int main(int argc, char **argv)
{
    wchar_t *program = Py_DecodeLocale(argv[0], NULL);
    if (program == NULL) {
        fprintf(stderr, "Fatal error: cannot decode argv[0]\n");
        exit(1);
    }

    PyImport_AppendInittab("lblcube", PyInit_lblcube);
    Py_SetProgramName(program);
    Py_Initialize();
    PyImport_ImportModule("lblcube");
    PyMem_RawFree(program);
    return 0;
}

//#ifdef DEBUG
//int main() {
//    Cube_t cb;
//    cout << "________________________| RUBIK'S CUBE SOLVER |________________________" << endl << endl;
//    cout << "Input :" << endl << endl;
//    cout << "White Side : ";
//    for (int i = 0; i < 9; ++i) { cin >> cb.up[i]; }
//    cout << "Red Side : ";
//    for (int i = 0; i < 9; ++i) { cin >> cb.front[i]; }
//    cout << "Orange Side : ";
//    for (int i = 0; i < 9; ++i) { cin >> cb.back[i]; }
//    cout << "Blue Side : ";
//    for (int i = 0; i < 9; ++i) { cin >> cb.ri[i]; }
//    cout << "Green Side : ";
//    for (int i = 0; i < 9; ++i) { cin >> cb.lft[i]; }
//    cout << "Yellow Side : ";
//    for (int i = 0; i < 9; ++i) { cin >> cb.bottom[i]; }
//    //-----------------------------------
//    cout << "\n-------------------------------------------------\n" << endl;
//    cout << "Turn these sides of the Cube in Clockwise Direction by 90 degrees in this exact order..." << endl << endl;
//    solve_white_cross(cb);
//    solve_white_corners(cb);
//    solve_middle_layer(cb);
//    solve_yellow_cross(cb);
//    solve_yellow_corners(cb);
//    yellow_corner_orientation(cb);
//    yellow_edges_colour_arrangement(cb);
//    //------------------------------------
//    cout << "\n\n-------------------------------------------------" << endl << endl;
//    cout << "Your Rubik's Cube is now SOLVED!\n\nOutput : " << endl << endl;
//    cout << "White Side : ";
//    display(cb.up);
//    cout << "Red Side : ";
//    display(cb.front);
//    cout << "Orange Side : ";
//    display(cb.back);
//    cout << "Blue Side : ";
//    display(cb.ri);
//    cout << "Green Side : ";
//    display(cb.lft);
//    cout << "Yellow Side : ";
//    display(cb.bottom);
//    return 0;
//}
//
//#endif

/*
owgbryybw
gowboowrr
bgrygrrgo
wyorgwrbb
ogbyywrwg
bowyogbyy
 */